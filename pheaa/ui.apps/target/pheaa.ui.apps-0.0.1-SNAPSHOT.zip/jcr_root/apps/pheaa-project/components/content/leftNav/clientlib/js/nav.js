var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");
ctx.fillStyle = "blue";
ctx.fillRect(0,10,153,150);
var canvas2 = document.getElementById("myCanvas");
var ctx2 = canvas2.getContext("2d");
ctx2.fillStyle = "green";
ctx2.fillRect(0,10,103,150);