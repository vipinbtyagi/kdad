$( document ).ready(function() {


            $("#takeQuiz").click(function() {

                // similar behavior as an HTTP redirect : same tab
				 //window.location.replace("http://google.com");

                 //this will redirect us in new tab
 				 window.open("http://google.com", '_blank');


            });

 });
