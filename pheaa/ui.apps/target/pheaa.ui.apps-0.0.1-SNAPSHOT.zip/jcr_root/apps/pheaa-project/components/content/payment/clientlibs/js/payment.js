$( document ).ready(function() {


            $("#makePaymentBtn").click(function() {

                // similar behavior as an HTTP redirect : same tab
				 //window.location.replace("http://stackoverflow.com");

                 //this will redirect us in new tab
 				 window.open("http://stackoverflow.com", '_blank');


            });

 });
